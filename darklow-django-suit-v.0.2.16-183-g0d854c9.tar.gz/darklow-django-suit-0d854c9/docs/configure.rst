Configure
=========

Documentation is in development.

Currently you can use demo app code as an example for v2: https://github.com/darklow/django-suit/blob/v2/demo/demo/apps.py

v2 live demo: http://v2.djangosuit.com/admin/

v2 demo app code: https://github.com/darklow/django-suit/tree/v2/demo
